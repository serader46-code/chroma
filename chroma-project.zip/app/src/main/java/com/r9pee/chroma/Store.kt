package com.r9pee.chroma

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Все настройки приложения. */
object Store {
    private lateinit var sp: SharedPreferences
    private var cachedParams: ColorParams? = null

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("chroma", Context.MODE_PRIVATE)
        }
    }

    var mode: String
        get() = sp.getString("mode", Chroma.MODE_SYSTEM) ?: Chroma.MODE_SYSTEM
        set(v) { sp.edit().putString("mode", v).apply() }

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    var params: ColorParams
        get() {
            cachedParams?.let { return it }
            val p = sp.getString("params", null)
                ?.let { runCatching { ColorParams.fromJson(JSONObject(it)) }.getOrNull() }
                ?: ColorParams()
            cachedParams = p
            return p
        }
        set(v) {
            cachedParams = v
            sp.edit().putString("params", v.toJson().toString()).apply()
        }

    var activePreset: String?
        get() = sp.getString("preset", "Стандарт")
        set(v) { sp.edit().putString("preset", v).apply() }

    var overlayColor: Int
        get() = sp.getInt("ov_color", 0xFFFF8A00.toInt())
        set(v) { sp.edit().putInt("ov_color", v).apply() }

    var overlayStrength: Float
        get() = sp.getFloat("ov_strength", 0.3f)
        set(v) { sp.edit().putFloat("ov_strength", v).apply() }

    fun customPresets(): List<Preset> = runCatching {
        val arr = JSONArray(sp.getString("custom", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Preset(o.getString("name"), ColorParams.fromJson(o.getJSONObject("p")), true)
        }
    }.getOrDefault(emptyList())

    fun saveCustom(name: String, p: ColorParams) {
        writeCustom(customPresets().filter { it.name != name } + Preset(name, p, true))
    }

    fun deleteCustom(name: String) {
        writeCustom(customPresets().filter { it.name != name })
    }

    private fun writeCustom(list: List<Preset>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("p", it.params.toJson())) }
        sp.edit().putString("custom", arr.toString()).apply()
    }
}
