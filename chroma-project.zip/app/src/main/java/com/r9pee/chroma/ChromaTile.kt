package com.r9pee.chroma

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Плитка в шторке быстрых настроек — включать/выключать прямо в игре. */
class ChromaTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        sync()
    }

    override fun onClick() {
        super.onClick()
        if (Store.enabled) {
            Chroma.turnOff(this)
            sync()
            return
        }
        if (Store.mode == Chroma.MODE_SYSTEM) {
            // Если приложение только что запустилось, Shizuku подключается не мгновенно.
            Chroma.whenShizukuReady(2000) { ready ->
                if (!ready || Chroma.turnOn(this) != null) openApp()
                sync()
            }
        } else {
            if (Chroma.turnOn(this) != null) openApp()
            sync()
        }
    }

    private fun sync() {
        val t = qsTile ?: return
        t.state = if (Store.enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Chroma"
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = when {
                !Store.enabled -> "Выкл"
                Store.mode == Chroma.MODE_OVERLAY -> "Фильтр"
                else -> Store.activePreset ?: "Свой"
            }
        }
        t.updateTile()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
