package com.r9pee.chroma

import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.quicksettings.TileService
import rikka.shizuku.Shizuku

/** Главный переключатель: включить / выключить / обновить эффект. */
object Chroma {
    const val MODE_SYSTEM = "system"
    const val MODE_OVERLAY = "overlay"

    /** Возвращает текст ошибки или null, если всё включилось. */
    fun turnOn(ctx: Context): String? {
        val err = if (Store.mode == MODE_SYSTEM) {
            applySystem()
        } else if (!Settings.canDrawOverlays(ctx)) {
            "Нужно разрешение «Поверх других приложений»"
        } else {
            null
        }
        if (err != null) return err
        Store.enabled = true
        ChromaService.start(ctx)
        updateTile(ctx)
        return null
    }

    fun turnOff(ctx: Context) {
        val wasSystem = Store.mode == MODE_SYSTEM
        Store.enabled = false
        if (wasSystem && SfColor.state() == SfColor.State.READY) SfColor.apply(null)
        ChromaService.stop(ctx)
        updateTile(ctx)
    }

    fun applySystem(): String? {
        when (SfColor.state()) {
            SfColor.State.NOT_RUNNING -> return "Shizuku не запущен"
            SfColor.State.NO_PERMISSION -> return "Нет доступа к Shizuku"
            SfColor.State.READY -> Unit
        }
        val p = Store.params
        val err = SfColor.apply(if (p.isIdentity()) null else ColorMath.columnMajor(p))
        return err?.let { "Ошибка: ${it.message ?: it.javaClass.simpleName}" }
    }

    /** Применить текущие настройки, если эффект включён. */
    fun refresh(ctx: Context): String? {
        if (!Store.enabled) return null
        return if (Store.mode == MODE_SYSTEM) {
            applySystem()
        } else {
            ChromaService.refreshOverlay(ctx)
            null
        }
    }

    fun setMode(ctx: Context, mode: String): String? {
        if (mode == Store.mode) return null
        val wasOn = Store.enabled
        if (wasOn) turnOff(ctx)
        Store.mode = mode
        return if (wasOn) turnOn(ctx) else null
    }

    /** Дождаться подключения к Shizuku (нужно, когда приложение только что запустилось). */
    fun whenShizukuReady(timeoutMs: Long, cb: (Boolean) -> Unit) {
        if (Shizuku.pingBinder()) {
            cb(true)
            return
        }
        val h = Handler(Looper.getMainLooper())
        var done = false
        lateinit var listener: Shizuku.OnBinderReceivedListener
        val timeout = Runnable {
            if (!done) {
                done = true
                Shizuku.removeBinderReceivedListener(listener)
                cb(false)
            }
        }
        listener = Shizuku.OnBinderReceivedListener {
            h.post {
                if (!done) {
                    done = true
                    h.removeCallbacks(timeout)
                    Shizuku.removeBinderReceivedListener(listener)
                    cb(true)
                }
            }
        }
        Shizuku.addBinderReceivedListener(listener, h)
        h.postDelayed(timeout, timeoutMs)
    }

    fun updateTile(ctx: Context) {
        runCatching { TileService.requestListeningState(ctx, ComponentName(ctx, ChromaTile::class.java)) }
    }
}
