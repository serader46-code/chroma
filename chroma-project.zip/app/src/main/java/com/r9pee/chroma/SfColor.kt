package com.r9pee.chroma

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Parcel
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/**
 * Настоящая цветокоррекция всего экрана через SurfaceFlinger.
 * Вызов идёт от имени shell (ADB) через Shizuku — рут не нужен.
 */
object SfColor {
    enum class State { NOT_RUNNING, NO_PERMISSION, READY }

    private const val TX_COLOR_MATRIX = 1015
    private const val DEFAULT_DESCRIPTOR = "android.ui.ISurfaceComposer"

    @Volatile private var binder: IBinder? = null
    @Volatile private var descriptor: String = DEFAULT_DESCRIPTOR

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (e: Throwable) {
        State.NOT_RUNNING
    }

    private fun surfaceFlinger(): IBinder {
        binder?.let { if (it.pingBinder()) return it }
        val raw = SystemServiceHelper.getSystemService("SurfaceFlinger")
            ?: throw IllegalStateException("SurfaceFlinger недоступен")
        descriptor = runCatching { raw.interfaceDescriptor }.getOrNull()
            ?.takeIf { it.isNotEmpty() } ?: DEFAULT_DESCRIPTOR
        return ShizukuBinderWrapper(raw).also { binder = it }
    }

    /** matrix = null — сброс к обычным цветам. Возвращает ошибку или null. */
    fun apply(matrix: FloatArray?): Throwable? = try {
        val sf = surfaceFlinger()
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(descriptor)
            if (matrix == null) {
                data.writeInt(0)
            } else {
                data.writeInt(1)
                for (v in matrix) data.writeFloat(v)
            }
            sf.transact(TX_COLOR_MATRIX, data, reply, 0)
        } finally {
            data.recycle()
            reply.recycle()
        }
        null
    } catch (t: Throwable) {
        binder = null
        t
    }
}
