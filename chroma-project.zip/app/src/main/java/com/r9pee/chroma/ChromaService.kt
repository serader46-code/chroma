package com.r9pee.chroma

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import rikka.shizuku.Shizuku

/**
 * Держит эффект включённым:
 *  • в режиме «Фильтр» рисует цветной слой поверх экрана;
 *  • в режиме «Система» возвращает цвета, если телефон их сбросил (экран включился, ночной режим и т.п.).
 */
class ChromaService : Service() {

    companion object {
        const val ACTION_OFF = "com.r9pee.chroma.OFF"
        private const val NOTIF_ID = 1

        @Volatile var instance: ChromaService? = null

        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, ChromaService::class.java))
            } catch (_: Exception) {
                // В режиме «Система» эффект уже применён, сервис только страхует.
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ChromaService::class.java))
        }

        fun refreshOverlay(ctx: Context) {
            val s = instance
            if (s != null) s.handler.post { s.sync() } else start(ctx)
        }
    }

    val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var watching = false

    private val reapply = Runnable {
        if (Store.enabled && Store.mode == Chroma.MODE_SYSTEM) Chroma.applySystem()
    }

    private fun scheduleReapply(delay: Long) {
        handler.removeCallbacks(reapply)
        handler.postDelayed(reapply, delay)
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = scheduleReapply(500)
    }

    private val nightObserver = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) = scheduleReapply(700)
    }

    private val binderListener = Shizuku.OnBinderReceivedListener { scheduleReapply(300) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (intent?.action == ACTION_OFF) {
            Chroma.turnOff(this)
            return START_NOT_STICKY
        }
        if (!Store.enabled) {
            stopSelf()
            return START_NOT_STICKY
        }
        sync()
        return START_STICKY
    }

    fun sync() {
        if (!Store.enabled) {
            stopSelf()
            return
        }
        if (Store.mode == Chroma.MODE_OVERLAY) {
            stopWatching()
            showOverlay()
        } else {
            hideOverlay()
            startWatching()
        }
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    override fun onDestroy() {
        instance = null
        hideOverlay()
        stopWatching()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---------- Уведомление ----------

    private fun goForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val off = PendingIntent.getForegroundService(
            this, 1, Intent(this, ChromaService::class.java).setAction(ACTION_OFF), PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (Store.mode == Chroma.MODE_SYSTEM) {
            "Режим: система" + (Store.activePreset?.let { " · $it" } ?: "")
        } else {
            "Режим: фильтр · ${(Store.overlayStrength * 100).toInt()}%"
        }
        return Notification.Builder(this, App.CHANNEL)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Chroma включён")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_tile), "Выключить", off).build()
            )
            .build()
    }

    // ---------- Режим «Фильтр» ----------

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WindowManager::class.java)
        val view = overlay ?: View(this)
        view.setBackgroundColor(Store.overlayColor or 0xFF000000.toInt())

        val size = screenSize(wm)
        val lp = (view.layoutParams as? WindowManager.LayoutParams) ?: WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        // Android 12+ пропускает касания сквозь слой только при прозрачности до 80%.
        lp.alpha = Store.overlayStrength.coerceIn(0f, 0.79f)

        try {
            if (overlay == null) {
                wm.addView(view, lp)
                overlay = view
            } else {
                wm.updateViewLayout(view, lp)
            }
        } catch (_: Exception) {
        }
    }

    private fun screenSize(wm: WindowManager): Int {
        val (w, h) = if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
        return maxOf(w, h) + 300
    }

    private fun hideOverlay() {
        overlay?.let {
            try {
                getSystemService(WindowManager::class.java).removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    // ---------- Режим «Система»: следим, чтобы эффект не слетал ----------

    private fun startWatching() {
        if (watching) return
        watching = true
        val f = IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_USER_PRESENT) }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
        runCatching {
            contentResolver.registerContentObserver(
                Settings.Secure.getUriFor("night_display_activated"), false, nightObserver
            )
        }
        Shizuku.addBinderReceivedListenerSticky(binderListener, handler)
    }

    private fun stopWatching() {
        if (!watching) return
        watching = false
        runCatching { unregisterReceiver(screenReceiver) }
        runCatching { contentResolver.unregisterContentObserver(nightObserver) }
        Shizuku.removeBinderReceivedListener(binderListener)
    }
}
