package com.r9pee.chroma

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Параметры цветокоррекции для режима «Система». */
data class ColorParams(
    val saturation: Float = 1f, // 0..3
    val contrast: Float = 1f,   // 0.5..2
    val brightness: Float = 0f, // -0.2..0.2
    val hue: Float = 0f,        // градусы -180..180
    val red: Float = 1f,        // 0..1.5
    val green: Float = 1f,
    val blue: Float = 1f,
    val invert: Boolean = false
) {
    fun isIdentity(): Boolean =
        !invert && near(saturation, 1f) && near(contrast, 1f) && near(brightness, 0f) &&
            near(hue, 0f) && near(red, 1f) && near(green, 1f) && near(blue, 1f)

    fun toJson(): JSONObject = JSONObject()
        .put("s", saturation.toDouble()).put("c", contrast.toDouble()).put("b", brightness.toDouble())
        .put("h", hue.toDouble()).put("r", red.toDouble()).put("g", green.toDouble())
        .put("bl", blue.toDouble()).put("i", invert)

    companion object {
        private fun near(a: Float, b: Float) = abs(a - b) < 0.001f

        fun fromJson(o: JSONObject) = ColorParams(
            saturation = o.optDouble("s", 1.0).toFloat(),
            contrast = o.optDouble("c", 1.0).toFloat(),
            brightness = o.optDouble("b", 0.0).toFloat(),
            hue = o.optDouble("h", 0.0).toFloat(),
            red = o.optDouble("r", 1.0).toFloat(),
            green = o.optDouble("g", 1.0).toFloat(),
            blue = o.optDouble("bl", 1.0).toFloat(),
            invert = o.optBoolean("i", false)
        )
    }
}

data class Preset(val name: String, val params: ColorParams, val custom: Boolean = false)

object Presets {
    val builtIn = listOf(
        Preset("Стандарт", ColorParams()),
        Preset("Сочный", ColorParams(saturation = 1.5f, contrast = 1.05f)),
        Preset("Тактика", ColorParams(saturation = 1.3f, contrast = 0.92f, brightness = 0.05f)),
        Preset("Неон", ColorParams(saturation = 2.2f, contrast = 1.15f)),
        Preset("Кино", ColorParams(saturation = 1.15f, contrast = 1.12f, green = 0.96f, blue = 0.88f)),
        Preset("Холод", ColorParams(saturation = 1.1f, red = 0.88f, green = 0.97f)),
        Preset("Ночь", ColorParams(saturation = 0.9f, green = 0.82f, blue = 0.55f, brightness = -0.02f)),
        Preset("Ч/Б", ColorParams(saturation = 0f, contrast = 1.1f)),
        Preset("Матрица", ColorParams(saturation = 0f, red = 0.35f, green = 1.15f, blue = 0.4f)),
        Preset("Кислота", ColorParams(saturation = 1.8f, hue = 90f)),
        Preset("Негатив", ColorParams(invert = true))
    )

    /** Цвета для режима «Фильтр». */
    val swatches: List<Pair<String, Int>> = listOf(
        "Ночь" to 0xFFFF8A00.toInt(),
        "Красный" to 0xFFFF1744.toInt(),
        "Розовый" to 0xFFFF2E88.toInt(),
        "Фиолет" to 0xFF7C3AED.toInt(),
        "Синий" to 0xFF2962FF.toInt(),
        "Бирюза" to 0xFF00E5FF.toInt(),
        "Зелёный" to 0xFF00E676.toInt(),
        "Тень" to 0xFF000000.toInt()
    )
}

/**
 * Собирает 4x4 матрицу цвета для SurfaceFlinger (транзакция 1015).
 * Порядок: оттенок → насыщенность → RGB → контраст → яркость → негатив.
 * Результат — column-major, как его читает SurfaceFlinger.
 */
object ColorMath {
    private class Affine(val a: FloatArray, val t: FloatArray) {
        /** Сначала this, потом next. */
        fun then(next: Affine): Affine {
            val na = FloatArray(9)
            val nt = FloatArray(3)
            for (r in 0..2) {
                for (c in 0..2) {
                    var s = 0f
                    for (k in 0..2) s += next.a[r * 3 + k] * a[k * 3 + c]
                    na[r * 3 + c] = s
                }
                var s = next.t[r]
                for (k in 0..2) s += next.a[r * 3 + k] * t[k]
                nt[r] = s
            }
            return Affine(na, nt)
        }
    }

    private fun linear(vararg a: Float) = Affine(a, floatArrayOf(0f, 0f, 0f))

    private val identity = linear(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)

    private fun hue(deg: Float): Affine {
        val rad = Math.toRadians(deg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        return linear(
            .213f + c * .787f - s * .213f, .715f - c * .715f - s * .715f, .072f - c * .072f + s * .928f,
            .213f - c * .213f + s * .143f, .715f + c * .285f + s * .140f, .072f - c * .072f - s * .283f,
            .213f - c * .213f - s * .787f, .715f - c * .715f + s * .715f, .072f + c * .928f + s * .072f
        )
    }

    private fun saturation(s: Float) = linear(
        .213f + .787f * s, .715f - .715f * s, .072f - .072f * s,
        .213f - .213f * s, .715f + .285f * s, .072f - .072f * s,
        .213f - .213f * s, .715f - .715f * s, .072f + .928f * s
    )

    private fun gains(r: Float, g: Float, b: Float) = linear(r, 0f, 0f, 0f, g, 0f, 0f, 0f, b)

    private fun contrast(c: Float): Affine {
        val o = (1f - c) / 2f
        return Affine(floatArrayOf(c, 0f, 0f, 0f, c, 0f, 0f, 0f, c), floatArrayOf(o, o, o))
    }

    private fun offset(b: Float) = Affine(identity.a, floatArrayOf(b, b, b))

    private val invert = Affine(floatArrayOf(-1f, 0f, 0f, 0f, -1f, 0f, 0f, 0f, -1f), floatArrayOf(1f, 1f, 1f))

    fun columnMajor(p: ColorParams): FloatArray {
        var m = identity
            .then(hue(p.hue))
            .then(saturation(p.saturation))
            .then(gains(p.red, p.green, p.blue))
            .then(contrast(p.contrast))
            .then(offset(p.brightness))
        if (p.invert) m = m.then(invert)

        val out = FloatArray(16)
        for (c in 0..2) {
            for (r in 0..2) out[c * 4 + r] = m.a[r * 3 + c]
            out[c * 4 + 3] = 0f
        }
        out[12] = m.t[0]
        out[13] = m.t[1]
        out[14] = m.t[2]
        out[15] = 1f
        return out
    }
}
