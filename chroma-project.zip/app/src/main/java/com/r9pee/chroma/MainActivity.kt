package com.r9pee.chroma

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import kotlin.math.abs
import kotlin.math.roundToInt

private val BG = 0xFF0A0A12.toInt()
private val CARD = 0xFF151522.toInt()
private val CARD2 = 0xFF22223A.toInt()
private val TRACK = 0xFF2A2A40.toInt()
private val TEXT = 0xFFFFFFFF.toInt()
private val MUTED = 0xFF8B8BA3.toInt()
private val PINK = 0xFFFF2E88.toInt()
private val VIOLET = 0xFF8B5CF6.toInt()
private val CYAN = 0xFF22D3EE.toInt()
private val GREEN = 0xFF34D399.toInt()
private val YELLOW = 0xFFFBBF24.toInt()
private val RED = 0xFFF87171.toInt()
private val CH_RED = 0xFFFF4D4D.toInt()
private val CH_GREEN = 0xFF3DDC84.toInt()
private val CH_BLUE = 0xFF4D8BFF.toInt()

class MainActivity : Activity() {

    companion object {
        private const val STEPS = 1000
        private const val REQ_SHIZUKU = 42
        private const val REQ_NOTIF = 7
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    }

    private class SliderRow(
        val view: View,
        private val seek: SeekBar,
        private val value: TextView,
        private val lo: Float,
        private val hi: Float,
        private val fmt: (Float) -> String
    ) {
        fun set(v: Float) {
            seek.progress = (((v - lo) / (hi - lo)) * STEPS).roundToInt().coerceIn(0, STEPS)
            value.text = fmt(v)
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var statusBtn: TextView
    private lateinit var powerBtn: TextView
    private lateinit var modeSys: TextView
    private lateinit var modeOv: TextView
    private lateinit var sysCard: LinearLayout
    private lateinit var ovCard: LinearLayout
    private lateinit var presetRow: LinearLayout
    private lateinit var swatchRow: LinearLayout
    private lateinit var invertSwitch: Switch
    private lateinit var strengthRow: SliderRow
    private val paramSliders = mutableListOf<Pair<SliderRow, (ColorParams) -> Float>>()
    private var syncing = false
    private var lastError: String? = null

    private val applyTask = Runnable { liveApply() }
    private val onBinder = Shizuku.OnBinderReceivedListener { render() }
    private val onDead = Shizuku.OnBinderDeadListener { render() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ ->
        render()
        if (Store.enabled) Chroma.refresh(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)

        buildHeader()
        buildStatus()
        buildPower()
        buildModeSwitch()
        buildSystemCard()
        buildOverlayCard()
        buildTips()

        Shizuku.addBinderReceivedListenerSticky(onBinder, h)
        Shizuku.addBinderDeadListener(onDead, h)
        Shizuku.addRequestPermissionResultListener(onPerm, h)
    }

    override fun onResume() {
        super.onResume()
        syncControls()
        render()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ================= Построение экрана =================

    private fun buildHeader() {
        val title = TextView(this).apply {
            text = "CHROMA"
            textSize = 44f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.06f
            setTextColor(Color.WHITE)
        }
        val w = title.paint.measureText("CHROMA") * 1.06f
        title.paint.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(PINK, VIOLET, CYAN), null, Shader.TileMode.CLAMP)
        root.addView(title)
        root.addView(text("Цвет экрана на максимум", 14f, MUTED).apply { setPadding(0, 0, 0, dp(16)) })
    }

    private fun buildStatus() {
        val c = card()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusDot = View(this)
        row.addView(statusDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
        statusText = text("", 14f, TEXT)
        row.addView(statusText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        statusBtn = pillButton("")
        row.addView(statusBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        c.addView(row)
        root.addView(c)
    }

    private fun buildPower() {
        powerBtn = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 20f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.12f
            setTextColor(Color.WHITE)
            setOnClickListener { togglePower() }
        }
        root.addView(powerBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)).apply { bottomMargin = dp(12) })
    }

    private fun buildModeSwitch() {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(CARD, dp(50).toFloat())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        modeSys = segment("СИСТЕМА") { switchMode(Chroma.MODE_SYSTEM) }
        modeOv = segment("ФИЛЬТР") { switchMode(Chroma.MODE_OVERLAY) }
        bar.addView(modeSys, LinearLayout.LayoutParams(0, dp(44), 1f))
        bar.addView(modeOv, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })
    }

    private fun buildSystemCard() {
        sysCard = card()
        sysCard.addView(section("ПРЕСЕТЫ"))
        presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sysCard.addView(
            HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(presetRow)
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(14) }
        )

        sysCard.addView(section("НАСТРОЙКА"))
        addParam("Насыщенность", 0f, 3f, 1f, 0.01f, ::pct, { it.saturation }) { p, v -> p.copy(saturation = v) }
        addParam("Контраст", 0.5f, 2f, 1f, 0.01f, ::pct, { it.contrast }) { p, v -> p.copy(contrast = v) }
        addParam("Яркость", -0.2f, 0.2f, 0f, 0.005f, ::signed, { it.brightness }, YELLOW) { p, v -> p.copy(brightness = v) }
        addParam("Оттенок", -180f, 180f, 0f, 1f, ::deg, { it.hue }, VIOLET) { p, v -> p.copy(hue = v) }
        addParam("Красный", 0f, 1.5f, 1f, 0.01f, ::pct, { it.red }, CH_RED) { p, v -> p.copy(red = v) }
        addParam("Зелёный", 0f, 1.5f, 1f, 0.01f, ::pct, { it.green }, CH_GREEN) { p, v -> p.copy(green = v) }
        addParam("Синий", 0f, 1.5f, 1f, 0.01f, ::pct, { it.blue }, CH_BLUE) { p, v -> p.copy(blue = v) }

        invertSwitch = Switch(this).apply {
            text = "Негатив"
            textSize = 15f
            setTextColor(TEXT)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(PINK, MUTED)
            )
            trackTintList = ColorStateList.valueOf(TRACK)
            setPadding(0, dp(10), 0, dp(4))
            setOnCheckedChangeListener { _, checked -> update { it.copy(invert = checked) } }
        }
        sysCard.addView(invertSwitch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val btns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        val reset = TextView(this).apply {
            text = "Сбросить"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(TEXT)
            background = rounded(CARD2, dp(50).toFloat())
            setOnClickListener { applyPreset(Presets.builtIn[0], autoOn = false) }
        }
        val save = pillButton("Сохранить пресет").apply { setOnClickListener { savePresetDialog() } }
        btns.addView(reset, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(8) })
        btns.addView(save, LinearLayout.LayoutParams(0, dp(46), 1f))
        sysCard.addView(btns)

        root.addView(sysCard)
    }

    private fun buildOverlayCard() {
        ovCard = card()
        ovCard.addView(section("ЦВЕТ ФИЛЬТРА"))
        swatchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ovCard.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(swatchRow)
        })
        strengthRow = slider("Сила", 0f, 0.8f, 0.3f, 0.01f, ::pct, PINK) { v ->
            if (!syncing) {
                Store.overlayStrength = v
                scheduleApply()
            }
        }
        ovCard.addView(strengthRow.view)
        ovCard.addView(
            text(
                "Фильтр кладёт цвет поверх экрана: ночной режим, затемнение, атмосфера для стрима. " +
                    "Сочность так не поднять — для неё режим «Система».",
                12f, MUTED
            ).apply { setPadding(0, dp(10), 0, 0) }
        )
        root.addView(ovCard)
    }

    private fun buildTips() {
        val c = card()
        c.addView(section("ФИШКИ"))
        listOf(
            "⚡ Плитка «Chroma» в шторке: опусти шторку → карандаш → перетащи плитку наверх. Включай и выключай прямо в игре.",
            "👆 Тап по цифре у ползунка — сброс к стандарту.",
            "★ Свои пресеты — кнопка «Сохранить пресет». Долгое нажатие на свой пресет — удалить.",
            "🔄 После перезагрузки телефона заново нажми «Запустить» в Shizuku.",
            "🌙 Режим «Система» перекрывает ночной режим телефона. После выключения Chroma переключи ночной режим ещё раз."
        ).forEach { c.addView(text(it, 13f, MUTED).apply { setPadding(0, dp(4), 0, dp(4)) }) }
        root.addView(c)
    }

    // ================= Элементы =================

    private fun addParam(
        title: String, lo: Float, hi: Float, def: Float, step: Float,
        fmt: (Float) -> String, get: (ColorParams) -> Float, color: Int = PINK,
        set: (ColorParams, Float) -> ColorParams
    ) {
        val row = slider(title, lo, hi, def, step, fmt, color) { v -> update { set(it, v) } }
        paramSliders += row to get
        sysCard.addView(row.view)
    }

    private fun slider(
        title: String, lo: Float, hi: Float, def: Float, step: Float,
        fmt: (Float) -> String, color: Int, onChange: (Float) -> Unit
    ): SliderRow {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(2))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(text(title, 14f, TEXT), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val value = text(fmt(def), 14f, color, bold = true)
        head.addView(value)
        box.addView(head)

        val seek = SeekBar(this).apply {
            this.max = STEPS
            progressTintList = ColorStateList.valueOf(color)
            thumbTintList = ColorStateList.valueOf(color)
            progressBackgroundTintList = ColorStateList.valueOf(TRACK)
        }
        box.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))

        val row = SliderRow(box, seek, value, lo, hi, fmt)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                var v = lo + (hi - lo) * progress / STEPS
                v = (v / step).roundToInt() * step
                if (abs(v - def) < step * 1.5f) v = def // лёгкий «магнит» к стандарту
                value.text = fmt(v)
                onChange(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        value.setOnClickListener {
            row.set(def)
            onChange(def)
        }
        row.set(def)
        return row
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(CARD, dp(20).toFloat())
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { bottomMargin = dp(12) }
    }

    private fun section(label: String) = text(label, 12f, MUTED, bold = true).apply {
        letterSpacing = 0.12f
        setPadding(0, 0, 0, dp(8))
    }

    private fun text(s: CharSequence, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pillButton(label: String) = TextView(this).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = gradient(dp(50).toFloat())
    }

    private fun segment(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
        setOnClickListener { onClick() }
    }

    private fun rounded(color: Int, r: Float, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r
        if (stroke > 0) setStroke(stroke, strokeColor)
    }

    private fun gradient(r: Float) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PINK, VIOLET, CYAN)).apply { cornerRadius = r }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun pct(v: Float) = "${(v * 100).roundToInt()}%"
    private fun signed(v: Float): String {
        val n = (v * 100).roundToInt()
        return if (n > 0) "+$n" else "$n"
    }
    private fun deg(v: Float) = "${v.roundToInt()}°"

    // ================= Состояние =================

    private fun render() {
        val sys = Store.mode == Chroma.MODE_SYSTEM
        modeSys.background = if (sys) gradient(dp(50).toFloat()) else null
        modeOv.background = if (!sys) gradient(dp(50).toFloat()) else null
        modeSys.setTextColor(if (sys) Color.WHITE else MUTED)
        modeOv.setTextColor(if (!sys) Color.WHITE else MUTED)
        sysCard.visibility = if (sys) View.VISIBLE else View.GONE
        ovCard.visibility = if (sys) View.GONE else View.VISIBLE

        if (sys) {
            when (SfColor.state()) {
                SfColor.State.READY -> setStatus(GREEN, "Shizuku подключён — полный контроль цвета", null, null)
                SfColor.State.NO_PERMISSION -> setStatus(YELLOW, "Shizuku запущен, нужен доступ", "Дать доступ") { requestShizuku() }
                SfColor.State.NOT_RUNNING -> setStatus(RED, "Shizuku не запущен", "Как включить") { showShizukuHelp() }
            }
        } else {
            if (Settings.canDrawOverlays(this)) {
                setStatus(GREEN, "Фильтр готов к работе", null, null)
            } else {
                setStatus(YELLOW, "Нужно разрешение на наложение", "Разрешить") { openOverlaySettings() }
            }
        }

        val on = Store.enabled
        powerBtn.text = if (on) "ВЫКЛЮЧИТЬ" else "ВКЛЮЧИТЬ"
        powerBtn.background = if (on) rounded(CARD, dp(22).toFloat(), dp(2), PINK) else gradient(dp(22).toFloat())
    }

    private fun setStatus(color: Int, msg: String, btn: String?, action: (() -> Unit)?) {
        statusDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        statusText.text = msg
        statusBtn.visibility = if (btn == null) View.GONE else View.VISIBLE
        statusBtn.text = btn ?: ""
        statusBtn.setOnClickListener { action?.invoke() }
    }

    private fun syncControls() {
        syncing = true
        val p = Store.params
        paramSliders.forEach { (row, get) -> row.set(get(p)) }
        invertSwitch.isChecked = p.invert
        strengthRow.set(Store.overlayStrength)
        syncing = false
        buildPresetChips()
        buildSwatches()
    }

    private fun buildPresetChips() {
        presetRow.removeAllViews()
        (Presets.builtIn + Store.customPresets()).forEach { pr ->
            val chip = TextView(this).apply {
                text = if (pr.custom) "★ ${pr.name}" else pr.name
                tag = pr.name
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                setOnClickListener { applyPreset(pr, autoOn = true) }
                if (pr.custom) setOnLongClickListener {
                    confirmDelete(pr.name)
                    true
                }
            }
            presetRow.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
        highlightPresets()
    }

    private fun highlightPresets() {
        val active = Store.activePreset
        for (i in 0 until presetRow.childCount) {
            val v = presetRow.getChildAt(i)
            v.background = if (v.tag == active) gradient(dp(50).toFloat()) else rounded(CARD2, dp(50).toFloat())
        }
    }

    private fun buildSwatches() {
        swatchRow.removeAllViews()
        Presets.swatches.forEach { (name, color) ->
            val selected = Store.overlayColor == color
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(4), dp(12), dp(8))
            }
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color)
                    setStroke(dp(if (selected) 3 else 1), if (selected) Color.WHITE else 0xFF3A3A55.toInt())
                }
            }
            col.addView(dot, LinearLayout.LayoutParams(dp(44), dp(44)))
            col.addView(text(name, 11f, if (selected) TEXT else MUTED).apply { setPadding(0, dp(4), 0, 0) })
            col.setOnClickListener {
                Store.overlayColor = color
                buildSwatches()
                if (Store.enabled) scheduleApply() else togglePower()
            }
            swatchRow.addView(col)
        }
    }

    // ================= Действия =================

    private fun update(f: (ColorParams) -> ColorParams) {
        if (syncing) return
        Store.params = f(Store.params)
        Store.activePreset = null
        highlightPresets()
        scheduleApply()
    }

    private fun scheduleApply() {
        h.removeCallbacks(applyTask)
        h.postDelayed(applyTask, 16)
    }

    private fun liveApply() {
        if (!Store.enabled) return
        val err = Chroma.refresh(this)
        if (err != null && err != lastError) {
            toast(err)
            render()
        }
        lastError = err
    }

    private fun applyPreset(p: Preset, autoOn: Boolean) {
        Store.params = p.params
        Store.activePreset = p.name
        syncControls()
        if (Store.enabled) scheduleApply() else if (autoOn) togglePower()
    }

    private fun togglePower() {
        if (Store.enabled) {
            Chroma.turnOff(this)
            render()
            return
        }
        askNotifications()
        val err = Chroma.turnOn(this)
        if (err != null) {
            toast(err)
            if (Store.mode == Chroma.MODE_SYSTEM) {
                when (SfColor.state()) {
                    SfColor.State.NO_PERMISSION -> requestShizuku()
                    SfColor.State.NOT_RUNNING -> showShizukuHelp()
                    SfColor.State.READY -> Unit
                }
            } else {
                openOverlaySettings()
            }
        }
        lastError = null
        render()
    }

    private fun switchMode(m: String) {
        if (Store.mode == m) return
        val err = Chroma.setMode(this, m)
        if (err != null) toast(err)
        render()
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                showShizukuHelp()
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                render()
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Доступ был запрещён. Открой Shizuku → «Управление приложениями» и включи Chroma")
                openShizuku()
                return
            }
            Shizuku.requestPermission(REQ_SHIZUKU)
        } catch (e: Throwable) {
            toast("Shizuku: ${e.message}")
        }
    }

    private fun showShizukuHelp() {
        val installed = packageManager.getLaunchIntentForPackage(SHIZUKU_PKG) != null
        val msg = "Shizuku даёт Chroma доступ к настоящей цветокоррекции экрана — без рута.\n\n" +
            "1. Установи Shizuku из Google Play.\n" +
            "2. Включи режим разработчика: Настройки → О телефоне → 7 раз нажми «Номер сборки».\n" +
            "3. Подключись к Wi-Fi. В Shizuku нажми «Сопряжение» и следуй подсказкам: " +
            "в «Для разработчиков» → «Отладка по Wi-Fi» → «Подключить по коду», код введи в уведомлении Shizuku.\n" +
            "4. В Shizuku нажми «Запустить».\n" +
            "5. Вернись в Chroma и нажми «Дать доступ».\n\n" +
            "После перезагрузки телефона повторяй только шаг 4."
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Как включить Shizuku")
            .setMessage(msg)
            .setPositiveButton(if (installed) "Открыть Shizuku" else "Скачать Shizuku") { _, _ ->
                if (installed) openShizuku() else downloadShizuku()
            }
            .setNegativeButton("Позже", null)
            .show()
    }

    private fun openShizuku() {
        packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)?.let { startActivity(it) } ?: downloadShizuku()
    }

    private fun downloadShizuku() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PKG")))
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PKG")))
        }
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            toast("Открой настройки → Приложения → Chroma → Поверх других приложений")
        }
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    private fun savePresetDialog() {
        val input = EditText(this).apply {
            hint = "Название"
            setTextColor(TEXT)
            setHintTextColor(MUTED)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val wrap = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Сохранить пресет")
            .setView(wrap)
            .setPositiveButton("Сохранить") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    Store.saveCustom(name, Store.params)
                    Store.activePreset = name
                    buildPresetChips()
                    toast("Пресет «$name» сохранён")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmDelete(name: String) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Удалить пресет «$name»?")
            .setPositiveButton("Удалить") { _, _ ->
                Store.deleteCustom(name)
                if (Store.activePreset == name) Store.activePreset = null
                buildPresetChips()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
