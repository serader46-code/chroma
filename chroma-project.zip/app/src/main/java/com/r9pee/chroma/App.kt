package com.r9pee.chroma

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.lsposed.hiddenapibypass.HiddenApiBypass

class App : Application() {
    companion object {
        const val CHANNEL = "chroma"
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { HiddenApiBypass.addHiddenApiExemptions("L") }
        }
        Store.init(this)
        val ch = NotificationChannel(CHANNEL, "Chroma", NotificationManager.IMPORTANCE_LOW).apply {
            setShowBadge(false)
            description = "Показывается, пока Chroma меняет цвета"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
}

/** После перезагрузки цвета сбрасываются сами, поэтому отмечаем Chroma выключенным. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            Store.init(c)
            Store.enabled = false
        }
    }
}
